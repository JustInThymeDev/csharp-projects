﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneNumberFormatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void formatButton_Click(object sender, EventArgs e)
        {
            string phoneNumber = phoneBox.Text;
            bool holdBool = true;
            foreach (char c in phoneNumber)
            {
                if (phoneNumber.All(char.IsDigit))
                {
                    holdBool = true;
                }
                else
                {
                    holdBool = false;
                }
            }
            if ((phoneNumber.Length != 10) || (holdBool== false))
            {
                MessageBox.Show("Invalid Length");
            }
            else
            {
                phoneBox.Text = ("(" + (phoneNumber.Substring(0, 3)) + ")-" + (phoneNumber.Substring(3, 3)) + "-") + (phoneNumber.Substring(6, 4));
            }
        }
    }
}
