﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PersonAndCusomer
{
    class PreferredCustomer : Customer
    {
        public double CumulativePurchases { get; set; }

        public double DiscountLevel
        {
            get
            {
                if (CumulativePurchases >= 2000)
                    return 0.10; // 10% discount
                else if (CumulativePurchases >= 1500)
                    return 0.07; // 7% discount
                else if (CumulativePurchases >= 1000)
                    return 0.06; // 6% discount
                else if (CumulativePurchases >= 500)
                    return 0.05; // 5% discount
                else
                    return 0.0;  // No discount
            }
        }
        public double CalcPurchase
        {
            get
            {
                double percentOff = DiscountLevel;
                double total = CumulativePurchases * (1 - percentOff);
                return total;
            }
        }
        public void prefferedToString()
        {
            Console.WriteLine(CumulativePurchases);
        }
    }
}
