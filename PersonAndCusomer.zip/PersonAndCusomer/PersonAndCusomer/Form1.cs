﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PersonAndCusomer
{
    public partial class Form1 : Form
    {
        //Customer 1
        PreferredCustomer customer1 = new PreferredCustomer
        {
            Name = "John Doe",
            Address = "123 Main St",
            PhoneNumber = "555-123-4567",
            CustomerNumber = 1001,
            IsOnMailingList = true,
            CumulativePurchases = 500
    };
        //Customer 2
        PreferredCustomer customer2 = new PreferredCustomer
        {
            Name = "Jane Doe",
            Address = "124 Main St",
            PhoneNumber = "111-111-1111",
            CustomerNumber = 1002,
            IsOnMailingList = true,
            CumulativePurchases = 1000
    };
        //Customer 3
        Customer customer3 = new Customer
        {
            Name = "Mike Pense",
            Address = "125 Main St",
            PhoneNumber = "222-222-222",
            CustomerNumber = 1003,
            IsOnMailingList = true,
    };
        //Customer 4
        Customer customer4 = new Customer
        {
            Name = "David Andrews",
            Address = "126 Main St",
            PhoneNumber = "333-333-3333",
            CustomerNumber = 1004,
            IsOnMailingList = true,
        };
        public Form1()
        {
            InitializeComponent();
        }

        public void button1_Click(object sender, EventArgs e)
        {
            object[] customers = {customer1, customer2, customer3, customer4};

            listBox1.Items.Add(customer1.Name);
            listBox1.Items.Add(customer2.Name);
            listBox1.Items.Add(customer3.Name);
            listBox1.Items.Add(customer4.Name);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBox1.SelectedIndex;
            if (index == 0)
            {
                label3.Text = customer1.Name;
                label5.Text = customer1.PhoneNumber;
                label7.Text = customer1.Address;
                label9.Text = customer1.CustomerNumber.ToString();
                label11.Text = customer1.IsOnMailingList.ToString();
                totalAmmt.Text = customer1.CalcPurchase.ToString();
            }
            if (index == 1)
            {
                label3.Text = customer2.Name;
                label5.Text = customer2.PhoneNumber;
                label7.Text = customer2.Address;
                label9.Text = customer2.CustomerNumber.ToString();
                label11.Text = customer2.IsOnMailingList.ToString();
                totalAmmt.Text = customer2.CalcPurchase.ToString();
            }
            if (index == 2)
            {
                label3.Text = customer3.Name;
                label5.Text = customer3.PhoneNumber;
                label7.Text = customer3.Address;
                label9.Text = customer3.CustomerNumber.ToString();
                label11.Text = customer3.IsOnMailingList.ToString();
                totalAmmt.Text = "NULL";
            }
            if (index == 3)
            {
                label3.Text = customer4.Name;
                label5.Text = customer4.PhoneNumber;
                label7.Text = customer4.Address;
                label9.Text = customer4.CustomerNumber.ToString();
                label11.Text = customer4.IsOnMailingList.ToString();
                totalAmmt.Text = "NULL";
            }
        }
    }
}
