﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PersonAndCusomer
{
    class Customer : Person
    {
        public int CustomerNumber { get; set; }
        public bool IsOnMailingList { get; set; }
        public double SpentAmount { get; set; }

        public void pcustomerToString()
        {
            Console.WriteLine(CustomerNumber.ToString(), IsOnMailingList, SpentAmount.ToString());
        }
    }
}
