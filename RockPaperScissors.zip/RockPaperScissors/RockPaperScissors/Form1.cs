﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace RockPaperScissors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int playerSelect;
        int playerScore = 0;
        int computerScore = 0;
private void rockSelect_Click(object sender, EventArgs e)
        {
            rockSelect.BackColor = Color.Red;
            playerSelect = 1;
        }

        private void paperSelect_Click(object sender, EventArgs e)
        {
            paperSelect.BackColor = Color.Red;
            playerSelect = 2;
        }

        private void scissorSelect_Click(object sender, EventArgs e)
        {
            scissorSelect.BackColor = Color.Red;
            playerSelect = 3;
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void runButton_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int compRandom = random.Next(1, 4);
            if ((playerSelect == 1) && (compRandom == 3))
            {
                MessageBox.Show("Player Wins");
                playerScore += 1;
            }
            if ((playerSelect == 2) && (compRandom == 1))
            {
                MessageBox.Show("Player Wins");
                playerScore += 1;
            }
            if ((playerSelect == 3) && (compRandom == 2))
            {
                MessageBox.Show("Player Wins");
                playerScore += 1;
            }
            if ((playerSelect == 3) && (compRandom == 1))
            {
                MessageBox.Show("Computer choose Rock, Computer Wins");
                computerScore += 1;
            }
            if ((playerSelect == 1) && (compRandom == 2))
            {
                MessageBox.Show("Computer choose Paper, Computer Wins");
                computerScore += 1;
            }
            if ((playerSelect == 2) && (compRandom == 3))
            {
                MessageBox.Show("Computer choose Scissors, Computer Wins");
                computerScore += 1;
            }
            button1.Text = playerScore.ToString();
            button2.Text = computerScore.ToString();

            rockSelect.BackColor = Color.Transparent;
            paperSelect.BackColor = Color.Transparent;
            scissorSelect.BackColor = Color.Transparent;
        }
    }
}
