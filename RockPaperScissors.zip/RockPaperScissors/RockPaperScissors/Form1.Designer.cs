﻿
namespace RockPaperScissors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.rockSelect = new System.Windows.Forms.PictureBox();
            this.scissorSelect = new System.Windows.Forms.PictureBox();
            this.paperSelect = new System.Windows.Forms.PictureBox();
            this.runButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.pScore = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.cScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.rockSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperSelect)).BeginInit();
            this.SuspendLayout();
            // 
            // rockSelect
            // 
            this.rockSelect.Image = ((System.Drawing.Image)(resources.GetObject("rockSelect.Image")));
            this.rockSelect.Location = new System.Drawing.Point(12, 12);
            this.rockSelect.Name = "rockSelect";
            this.rockSelect.Size = new System.Drawing.Size(150, 150);
            this.rockSelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.rockSelect.TabIndex = 0;
            this.rockSelect.TabStop = false;
            this.rockSelect.Click += new System.EventHandler(this.rockSelect_Click);
            // 
            // scissorSelect
            // 
            this.scissorSelect.Image = ((System.Drawing.Image)(resources.GetObject("scissorSelect.Image")));
            this.scissorSelect.Location = new System.Drawing.Point(88, 168);
            this.scissorSelect.Name = "scissorSelect";
            this.scissorSelect.Size = new System.Drawing.Size(150, 150);
            this.scissorSelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.scissorSelect.TabIndex = 1;
            this.scissorSelect.TabStop = false;
            this.scissorSelect.Click += new System.EventHandler(this.scissorSelect_Click);
            // 
            // paperSelect
            // 
            this.paperSelect.BackColor = System.Drawing.Color.Transparent;
            this.paperSelect.Image = ((System.Drawing.Image)(resources.GetObject("paperSelect.Image")));
            this.paperSelect.Location = new System.Drawing.Point(169, 12);
            this.paperSelect.Name = "paperSelect";
            this.paperSelect.Size = new System.Drawing.Size(150, 150);
            this.paperSelect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.paperSelect.TabIndex = 2;
            this.paperSelect.TabStop = false;
            this.paperSelect.Click += new System.EventHandler(this.paperSelect_Click);
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(254, 202);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(55, 31);
            this.runButton.TabIndex = 3;
            this.runButton.Text = "Go";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(254, 254);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(55, 31);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // pScore
            // 
            this.pScore.AutoSize = true;
            this.pScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pScore.Location = new System.Drawing.Point(9, 183);
            this.pScore.Name = "pScore";
            this.pScore.Size = new System.Drawing.Size(69, 13);
            this.pScore.TabIndex = 5;
            this.pScore.Text = "Player Score:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 199);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "0";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(12, 245);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "0";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // cScore
            // 
            this.cScore.AutoSize = true;
            this.cScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cScore.Location = new System.Drawing.Point(2, 229);
            this.cScore.Name = "cScore";
            this.cScore.Size = new System.Drawing.Size(85, 13);
            this.cScore.TabIndex = 7;
            this.cScore.Text = "Computer Score:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(331, 331);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cScore);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pScore);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.paperSelect);
            this.Controls.Add(this.scissorSelect);
            this.Controls.Add(this.rockSelect);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.rockSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.scissorSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paperSelect)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox rockSelect;
        private System.Windows.Forms.PictureBox scissorSelect;
        private System.Windows.Forms.PictureBox paperSelect;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label pScore;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label cScore;
    }
}

