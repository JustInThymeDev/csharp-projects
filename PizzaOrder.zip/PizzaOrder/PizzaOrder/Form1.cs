﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOrder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double toppingsTotal = 0;
        double basePizzaCost = 0;
        double appsCost = 0;
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                basePizzaCost = 12;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                basePizzaCost = 16;
                checkBox1.Checked = false;
                checkBox3.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
            {
                basePizzaCost = 20;
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox4.Checked = false;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
            {
                basePizzaCost = 24;
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
            }
        }
        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox16.Checked)
            {
                appsCost += 6;
            }
            else if (!checkBox16.Checked)
            {
                appsCost -= 6;
            }
        }

        private void checkBox15_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox15.Checked)
            {
                appsCost += 9;
            }
            else if (!checkBox15.Checked)
            {
                appsCost -= 9;
            }
        }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox14.Checked)
            {
                appsCost += 6;
            }
            else if (!checkBox14.Checked)
            {
                appsCost -= 6;
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox13.Checked)
            {
                appsCost += 6;
            }
            else if (!checkBox13.Checked)
            {
                appsCost -= 6;
            }
        }


        private void calcButton_Click(object sender, EventArgs e)
        {
            toppingsTotal = 0;
            foreach (CheckBox box in groupBox2.Controls.OfType<CheckBox>())
            {
                if (box.Checked)
                {
                    toppingsTotal += 1.5;
                }
            }
            double subTotal = basePizzaCost + toppingsTotal + appsCost;
            double afterTax = subTotal * .1014;
            double Total = subTotal + afterTax;
            subLabel.Text = "$" + subTotal;
            taxLabel.Text = "$" + afterTax;
            totalLabel.Text = "$" + Total;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
