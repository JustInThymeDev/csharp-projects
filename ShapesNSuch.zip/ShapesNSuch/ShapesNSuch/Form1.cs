﻿using ShapeProjectInClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShapesNSuch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            double d2 = Convert.ToDouble(d2TextBox.Text);
            Square square = new Square(shapeId, d1)
            {
                Side = d1,
            };
            typeLabel.Text = square.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = "NULL";
            area.Text = square.Area.ToString();
            volume.Text = "NULL";
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Square.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            double d2 = Convert.ToDouble(d2TextBox.Text);
            Triangle triangle = new Triangle(shapeId, d1, d2)
            {
                TheBase = d1,
                Height = d2
            };
            typeLabel.Text = triangle.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = d2.ToString();
            area.Text = triangle.Area.ToString();
            volume.Text = "NULL";
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Triangle.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            Circle circle = new Circle(shapeId, d1, 0)
            {
                Radius = d1,
            };
            typeLabel.Text = circle.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = "NULL";
            area.Text = circle.Area.ToString();
            volume.Text = "NULL";
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Circle.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            double d2 = Convert.ToDouble(d2TextBox.Text);
            Cube cube = new Cube(shapeId, d1)
            {
                Side = d1,
            };
            typeLabel.Text = cube.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = "NULL";
            area.Text = "NULL";
            volume.Text = cube.Volume.ToString(); 
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Cube.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            double d2 = Convert.ToDouble(d2TextBox.Text);
            Pyramid pyramid = new Pyramid(shapeId, d1, d2)
            {
                TheBase = d1,
                Height = d2
            };
            typeLabel.Text = pyramid.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = d2.ToString();
            area.Text = "NULL";
            volume.Text = pyramid.Volume.ToString();
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Pyramid.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string shapeId = IDTextBox.Text;
            double d1 = Convert.ToDouble(d1TextBox.Text);
            double d2 = Convert.ToDouble(d2TextBox.Text);
            Sphere sphere = new Sphere(shapeId, d1, 0)
            {
                Radius = d1,
            };
            typeLabel.Text = sphere.Name;
            this.shapeId.Text = shapeId;
            sLength.Text = d1.ToString();
            hLength.Text = "NULL";
            area.Text = "NULL";
            volume.Text = sphere.Volume.ToString();
            string imagePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sphere.png");
            pictureBox1.Image = Image.FromFile(imagePath);
        }
    }
}
