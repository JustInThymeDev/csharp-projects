﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShapeProjectInClass
{
    class Circle : TwoDimensionalShape
    {
        public Circle(string id, double theBase, double height)
            : base(id, theBase, height)
        { }

        public double Radius
        {
            get { return Dimension1; }
            set { Dimension1 = value; }
        }
        public override string Name
        {
            get { return "Circle"; }
        }
        public override double Area
        {
            get { return 3.1415926 * (Radius * Radius); }
        }

        override
        public string ToString()
        {
            return base.ToString() + "\n" +
                "Radius: " + Radius + "\n" +
                "Area: " + Area + "\n";
        }
    }
}