﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShapeProjectInClass
{
    class Sphere : ThreeDimensionalShape
    {
        public Sphere(string id, double theBase, double height)
            : base(id, theBase, height)
        { }

        public double Radius
        {
            get { return Dimension1; }
            set { Dimension1 = value; }
        }
        public override string Name
        {
            get { return "Sphere"; }
        }
        public override double Volume
        {
            get { return 1.33 * (3.1415926 * (Radius * Radius * Radius)); }
        }

        override
        public string ToString()
        {
            return base.ToString() + "\n" +
                "Radius: " + Radius + "\n" +
                "Volume: " + Volume + "\n";
        }
    }
}
