﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShapeProjectInClass
{
    abstract class TwoDimensionalShape : Shape
    {
        // properties
        public double Dimension1 { get; set; }

        public double Dimension2 { get; set; }


        public TwoDimensionalShape(string id, double dim1, double dim2)
            : base(id)
        {
            Dimension1 = dim1;
            Dimension2 = dim2;
        }

        public abstract double Area { get; }

        override
        public string ToString()
        {
            return base.ToString() + "Dimension 1: " + Dimension1 + "\n" +
                "Dimension 2: " + Dimension2 + "\n";
        }
    }
}
