﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShapeProjectInClass
{
    abstract class Shape
    {
        public abstract string Name { get; }

        public string Id { get; set; }

        public Shape(string id)
        {
            Id = id;
        }

        override
        public string ToString()
        {
            return "ID:" + Id + "\n";
        }
    }
}
