﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShapeProjectInClass
{
    class Triangle : TwoDimensionalShape
    {
        public Triangle(string id, double theBase, double height)
            : base(id, theBase, height)
        { }

        public double Height
        {
            get { return Dimension2; }
            set { Dimension2 = value; }
        }

        public double TheBase
        {
            get { return Dimension1; }
            set { Dimension1 = value; }
        }
        public override string Name
        {
            get { return "Triangle"; }
        }
        public override double Area
        {
            get { return (0.5) * Height * TheBase; }
        }

        override
        public string ToString()
        {
            return base.ToString() + "\n" +
                "Base: " + TheBase + "\n" +
                "Height: " + Height + "\n" +
                "Area: " + Area + "\n";
        }
    }
}
