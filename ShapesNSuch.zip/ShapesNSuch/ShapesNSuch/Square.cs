﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ShapeProjectInClass
{
    class Square : TwoDimensionalShape
    {
        public Square(string id, double side)
            : base(id, side, side)
        {
        }

        public override string Name
        {
            get { return "Square"; }
        }
        public double Side
        {
            get { return Dimension1; }
            set
            {
                Dimension1 = value;
                Dimension2 = value;
            }
        }
        public override double Area
        {
            get { return Side * Side; }
        }

        override
        public string ToString()
        {
            return base.ToString() + "Side: " + Side + "\n" +
                 "Area: " + Area + "\n";
        }
    }
}
