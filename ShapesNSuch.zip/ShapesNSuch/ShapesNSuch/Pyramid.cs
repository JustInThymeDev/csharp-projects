﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShapeProjectInClass
{
    class Pyramid : ThreeDimensionalShape
    {
        public Pyramid(string id, double theBase, double height)
            : base(id, theBase, height)
        { }

        public double Height
        {
            get { return Dimension2; }
            set { Dimension2 = value; }
        }

        public double TheBase
        {
            get { return Dimension1; }
            set { value = (Dimension1 * Dimension1); }
        }
        public override string Name
        {
            get { return "Triangle"; }
        }
        public override double Volume
        {
            get { return (Height * TheBase)/3; }
        }

        override
        public string ToString()
        {
            return base.ToString() + "\n" +
                "Base: " + TheBase + "\n" +
                "Height: " + Height + "\n" +
                "Volume: " + Volume + "\n";
        }
    }
}