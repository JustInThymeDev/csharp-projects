﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShapeProjectInClass
{
    class Cube : ThreeDimensionalShape
    {
        public Cube(string id, double side)
            : base(id, side, side)
        {
        }

        public override string Name
        {
            get { return "Cube"; }
        }
        public double Side
        {
            get { return Dimension1; }
            set
            {
                Dimension1 = value;
                Dimension2 = value;
            }
        }
        public override double Volume
        {
            get { return 6 * (Side * Side); }
        }

        override
        public string ToString()
        {
            return base.ToString() + "Side: " + Side + "\n" +
                 "volume: " + Volume + "\n";
        }
    }
}

