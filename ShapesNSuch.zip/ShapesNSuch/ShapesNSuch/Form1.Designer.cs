﻿
namespace ShapesNSuch
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.shapeId = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.IDTextBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.d2TextBox = new System.Windows.Forms.TextBox();
            this.d1TextBox = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.volume = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.area = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.hLength = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.sLength = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.typeLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.typeLabel);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.shapeId);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.IDTextBox);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.button7);
            this.groupBox1.Controls.Add(this.d2TextBox);
            this.groupBox1.Controls.Add(this.d1TextBox);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.volume);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.area);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.hLength);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.sLength);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(776, 430);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shapes";
            // 
            // shapeId
            // 
            this.shapeId.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.shapeId.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.shapeId.Location = new System.Drawing.Point(529, 170);
            this.shapeId.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.shapeId.Name = "shapeId";
            this.shapeId.Size = new System.Drawing.Size(130, 23);
            this.shapeId.TabIndex = 21;
            this.shapeId.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(390, 168);
            this.label13.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(133, 23);
            this.label13.TabIndex = 20;
            this.label13.Text = "Shape ID";
            // 
            // IDTextBox
            // 
            this.IDTextBox.Location = new System.Drawing.Point(529, 364);
            this.IDTextBox.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.IDTextBox.Name = "IDTextBox";
            this.IDTextBox.Size = new System.Drawing.Size(130, 22);
            this.IDTextBox.TabIndex = 19;
            this.IDTextBox.Text = "square1";
            this.IDTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(390, 363);
            this.label9.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(133, 23);
            this.label9.TabIndex = 18;
            this.label9.Text = "Shape ID";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(390, 392);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(269, 23);
            this.button7.TabIndex = 17;
            this.button7.Text = "Exit";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // d2TextBox
            // 
            this.d2TextBox.Location = new System.Drawing.Point(529, 337);
            this.d2TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.d2TextBox.Name = "d2TextBox";
            this.d2TextBox.Size = new System.Drawing.Size(130, 22);
            this.d2TextBox.TabIndex = 16;
            this.d2TextBox.Text = "0";
            this.d2TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // d1TextBox
            // 
            this.d1TextBox.Location = new System.Drawing.Point(529, 310);
            this.d1TextBox.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.d1TextBox.Name = "d1TextBox";
            this.d1TextBox.Size = new System.Drawing.Size(130, 22);
            this.d1TextBox.TabIndex = 15;
            this.d1TextBox.Text = "0";
            this.d1TextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(390, 336);
            this.label10.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(133, 23);
            this.label10.TabIndex = 13;
            this.label10.Text = "Dimension 2";
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(390, 309);
            this.label12.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(133, 23);
            this.label12.TabIndex = 11;
            this.label12.Text = "Dimension 1";
            // 
            // volume
            // 
            this.volume.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.volume.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.volume.Location = new System.Drawing.Point(529, 282);
            this.volume.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.volume.Name = "volume";
            this.volume.Size = new System.Drawing.Size(130, 23);
            this.volume.TabIndex = 10;
            this.volume.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(390, 282);
            this.label6.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(133, 23);
            this.label6.TabIndex = 9;
            this.label6.Text = "Volume (3D)";
            // 
            // area
            // 
            this.area.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.area.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.area.Location = new System.Drawing.Point(529, 254);
            this.area.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.area.Name = "area";
            this.area.Size = new System.Drawing.Size(130, 23);
            this.area.TabIndex = 8;
            this.area.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(390, 254);
            this.label8.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(133, 23);
            this.label8.TabIndex = 7;
            this.label8.Text = "Area (2D)";
            // 
            // hLength
            // 
            this.hLength.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.hLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.hLength.Location = new System.Drawing.Point(529, 226);
            this.hLength.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.hLength.Name = "hLength";
            this.hLength.Size = new System.Drawing.Size(130, 23);
            this.hLength.TabIndex = 6;
            this.hLength.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(390, 226);
            this.label4.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(133, 23);
            this.label4.TabIndex = 5;
            this.label4.Text = "Height";
            // 
            // sLength
            // 
            this.sLength.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.sLength.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.sLength.Location = new System.Drawing.Point(529, 198);
            this.sLength.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.sLength.Name = "sLength";
            this.sLength.Size = new System.Drawing.Size(130, 23);
            this.sLength.TabIndex = 4;
            this.sLength.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(390, 198);
            this.label1.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 23);
            this.label1.TabIndex = 3;
            this.label1.Text = "Side Length";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(6, 136);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(378, 284);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.button3);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Controls.Add(this.button1);
            this.groupBox3.Location = new System.Drawing.Point(390, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(380, 109);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "3D Shapes";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(271, 45);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Sphere";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(26, 45);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cube";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(155, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Pyramid";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button4);
            this.groupBox2.Controls.Add(this.button5);
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Location = new System.Drawing.Point(6, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(378, 109);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "2D Shapes";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(273, 45);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 5;
            this.button4.Text = "Circle";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(28, 45);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Square";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(157, 45);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 3;
            this.button6.Text = "Triangle";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // typeLabel
            // 
            this.typeLabel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.typeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.typeLabel.Location = new System.Drawing.Point(529, 142);
            this.typeLabel.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.typeLabel.Name = "typeLabel";
            this.typeLabel.Size = new System.Drawing.Size(130, 23);
            this.typeLabel.TabIndex = 23;
            this.typeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(390, 140);
            this.label3.Margin = new System.Windows.Forms.Padding(3, 2, 2, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 23);
            this.label3.TabIndex = 22;
            this.label3.Text = "Shape Type";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label volume;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label area;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label hLength;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label sLength;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TextBox d2TextBox;
        private System.Windows.Forms.TextBox d1TextBox;
        private System.Windows.Forms.TextBox IDTextBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label shapeId;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label typeLabel;
        private System.Windows.Forms.Label label3;
    }
}

