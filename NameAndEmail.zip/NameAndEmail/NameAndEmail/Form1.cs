﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace NameAndEmail
{
    struct PhoneBookEntry
    {
        public string name;
        public string phone;
    }

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        private List<PhoneBookEntry> entries = new List<PhoneBookEntry>();
        private void ReadFile()
        {
            StreamReader inputFile = File.OpenText("emailList.txt");
            try
            {
                PhoneBookEntry entry = new PhoneBookEntry();

                char[] delim = { ',' };

                string line;

                while (!inputFile.EndOfStream)
                {
                    line = inputFile.ReadLine().Trim();

                    string[] tokens = line.Split(delim);

                    entry.name = tokens[0];
                    entry.phone = tokens[1];

                    entries.Add(entry);
                }
            }
            catch
            {
                MessageBox.Show("The file is unreadable.");
            }
            inputFile.Close();
        }

        private void DisplayNames()
        {
            foreach (PhoneBookEntry person in entries)
            {
                nameListBox.Items.Add(person.name);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ReadFile();
            DisplayNames();
        }

        private void nameListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = nameListBox.SelectedIndex;
            inBox.Text = entries[index].name;
            outLabel.Text = entries[index].phone;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            string inName = inBox.Text;
            string inEmail = outLabel.Text;
            using (StreamWriter sw = File.AppendText("emailList.txt"))
            {
                sw.WriteLine(inName + "," + inEmail);
            }
            MessageBox.Show("Item Added");
        }

        private void editButton_Click(object sender, EventArgs e)
        {
            string inName = inBox.Text;
            string inEmail = outLabel.Text;
            int index = nameListBox.SelectedIndex;
            var file = new List<string>(System.IO.File.ReadAllLines("emailList.txt"));
            file.RemoveAt(index);
            File.WriteAllLines("emailList.txt", file.ToArray());
            using (StreamWriter sw = File.AppendText("emailList.txt"))
            {
                sw.WriteLine(inName + "," + inEmail);
            }
            MessageBox.Show("Item Edited");

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            int index = nameListBox.SelectedIndex;
            var file = new List<string>(System.IO.File.ReadAllLines("emailList.txt"));
            file.RemoveAt(index);
            File.WriteAllLines("emailList.txt", file.ToArray());
            MessageBox.Show("Item Removed");
        }
    }
}
