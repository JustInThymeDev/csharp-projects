﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace StringParso
{
    public partial class Form1 : Form
    {
        public char[] vowels = new[] { 'a', 'A', 'e', 'E', 'i', 'I', 'o', 'O', 'u', 'U' };
        int count = 0;
        TextInfo textInfo = new CultureInfo("en-US", false).TextInfo;
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void runButton_Click(object sender, EventArgs e)
        {
            count = 0;
            string subjectString = textBox.Text;
            string[] wordsIn = subjectString.Split(null);
            foreach (string s in wordsIn)
            {
                foreach (char vowel in vowels)
                {
                    if (s.Contains(vowel))
                    {
                        count += 1;
                    }
                }

            }
            wordCount.Text = (wordsIn.Length).ToString();
            camelBox.Text = textInfo.ToTitleCase(subjectString);
            vowelBox.Text = count.ToString();
        }
    }
}
