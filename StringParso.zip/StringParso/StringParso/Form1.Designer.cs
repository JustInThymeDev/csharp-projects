﻿
namespace StringParso
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.wordLabel = new System.Windows.Forms.Label();
            this.wordCount = new System.Windows.Forms.Button();
            this.camelBox = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.vowelBox = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.runButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(32, 102);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(267, 22);
            this.textBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("NSimSun", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 74);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please enter a some text and ill tell you a little about it:";
            // 
            // wordLabel
            // 
            this.wordLabel.AutoSize = true;
            this.wordLabel.Font = new System.Drawing.Font("NSimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordLabel.Location = new System.Drawing.Point(12, 145);
            this.wordLabel.Name = "wordLabel";
            this.wordLabel.Size = new System.Drawing.Size(259, 14);
            this.wordLabel.TabIndex = 2;
            this.wordLabel.Text = "How many words are in this sentence:";
            // 
            // wordCount
            // 
            this.wordCount.Location = new System.Drawing.Point(384, 140);
            this.wordCount.Name = "wordCount";
            this.wordCount.Size = new System.Drawing.Size(210, 23);
            this.wordCount.TabIndex = 3;
            this.wordCount.UseVisualStyleBackColor = true;
            // 
            // camelBox
            // 
            this.camelBox.Location = new System.Drawing.Point(277, 174);
            this.camelBox.Name = "camelBox";
            this.camelBox.Size = new System.Drawing.Size(317, 23);
            this.camelBox.TabIndex = 5;
            this.camelBox.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("NSimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 179);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(203, 14);
            this.label2.TabIndex = 4;
            this.label2.Text = "Lets put this in camel case:";
            // 
            // vowelBox
            // 
            this.vowelBox.Location = new System.Drawing.Point(384, 211);
            this.vowelBox.Name = "vowelBox";
            this.vowelBox.Size = new System.Drawing.Size(210, 23);
            this.vowelBox.TabIndex = 7;
            this.vowelBox.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("NSimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 216);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(266, 14);
            this.label3.TabIndex = 6;
            this.label3.Text = "How many vowels are in this sentence:";
            // 
            // runButton
            // 
            this.runButton.Font = new System.Drawing.Font("NSimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.runButton.Location = new System.Drawing.Point(15, 269);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(75, 23);
            this.runButton.TabIndex = 8;
            this.runButton.Text = "Run";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("NSimSun", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(113, 269);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 9;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 450);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.vowelBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.camelBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.wordCount);
            this.Controls.Add(this.wordLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label wordLabel;
        private System.Windows.Forms.Button wordCount;
        private System.Windows.Forms.Button camelBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button vowelBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Button exitButton;
    }
}

