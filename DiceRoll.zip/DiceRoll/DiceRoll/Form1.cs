﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiceRoll
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void rollButton_Click(object sender, EventArgs e)
        {
            int roll1, roll2;
            Random random = new Random();
            roll1 = random.Next(1, 7);
            roll2 = random.Next(1, 7);

            if (roll1 == 1)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die1.bmp");
            }
            if (roll1 == 2)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die2.bmp");
            }
            if (roll1 == 3)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die3.bmp");
            }
            if (roll1 == 4)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die4.bmp");
            }
            if (roll1 == 5)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die5.bmp");
            }
            if (roll1 == 6)
            {
                Dice1.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die6.bmp");
            }
            if (roll2 == 1)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die1.bmp");
            }
            if (roll2 == 2)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die2.bmp");
            }
            if (roll2 == 3)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die3.bmp");
            }
            if (roll2 == 4)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die4.bmp");
            }
            if (roll2 == 5)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die5.bmp");
            }
            if (roll2 == 6)
            {
                Dice2.Image = new Bitmap(@"C:\Users\1jade\source\repos\DiceRoll\DiceRoll\Resources\Die6.bmp");
            }
        }
    }
}
