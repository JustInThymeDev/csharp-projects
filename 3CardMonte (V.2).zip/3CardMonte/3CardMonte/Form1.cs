﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using System.IO;

namespace _3CardMonte
{
    public partial class Form1 : Form
    {
        private System.Timers.Timer myTimer;
        Random random = new Random();
        double total = 20.00;
        string winState;
        public Form1()
        {
            InitializeComponent();
            coinSelect();
            myTimer = new System.Timers.Timer(10);
            myTimer.Elapsed += new System.Timers.ElapsedEventHandler(myTimer_Elapsed);
            myTimer.AutoReset = true;
            myTimer.SynchronizingObject = this;
            if (!File.Exists("gameHistory.txt"))
            {
                File.Create("gameHistory.txt").Close();
            }
        }

        private int coinSelect()
        {
            try
            {
                Convert.ToDouble(betIn.Text);
            }
            catch
            {
                MessageBox.Show("Please input a bet ammount.");
            }
            int magic_coin = random.Next(1, 4);
            if (magic_coin == 1)
            {
                coin1.Visible = true;
                coin2.Visible = false;
                coin3.Visible = false;
            }
            else if (magic_coin == 2)
            {
                coin1.Visible = false;
                coin2.Visible = true;
                coin3.Visible = false;
            }
            else if (magic_coin == 3)
            {
                coin1.Visible = false;
                coin2.Visible = false;
                coin3.Visible = true;
            }
            return magic_coin;
        }

        private void myTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            coin1.Visible = false;
            coin2.Visible = false;
            coin3.Visible = false;
            while (cup1.Location.Y <= 140)
            {
                cup1.Location = new Point(cup1.Location.X, cup1.Location.Y + 1);
                cup2.Location = new Point(cup2.Location.X, cup2.Location.Y + 1);
                cup3.Location = new Point(cup3.Location.X, cup3.Location.Y + 1);
            }
            myTimer.Enabled = false;
        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void runButton_Click(object sender, EventArgs e)
        {
            coinSelect();
            myTimer.Enabled = true;

        }



        private void cup1_Click(object sender, EventArgs e)
        {
            double bidAmmt = Convert.ToDouble(betIn.Text);
            int magic_coin = coinSelect();
            while (cup1.Location.Y >= 44)
            {
                cup1.Location = new Point(cup1.Location.X, cup1.Location.Y - 1);
                cup2.Location = new Point(cup2.Location.X, cup2.Location.Y - 1);
                cup3.Location = new Point(cup3.Location.X, cup3.Location.Y - 1);
            }
            myTimer.Enabled = false;
            using (StreamWriter outFile = File.AppendText("gameHistory.txt")) ;
            if (magic_coin == 1)
            {
                winStatus.Text = "Win";
                winState = "win";
                total += bidAmmt;
            }
            else
            {
                winStatus.Text = "Lose";
                winState = "lose";
                total -= bidAmmt;
            }
            moneyOut.Text = "$" + total;
            using (StreamWriter outFile = File.AppendText("gameHistory.txt"))
            {
                outFile.WriteLine("Game Win, Cup 3 Choose " + betIn.Text + " " + total.ToString() + "\n");
            }
        }

        private void cup2_Click(object sender, EventArgs e)
        {
            double bidAmmt = Convert.ToDouble(betIn.Text);
            int magic_coin = coinSelect();
            while (cup1.Location.Y >= 44)
            {
                cup1.Location = new Point(cup1.Location.X, cup1.Location.Y - 1);
                cup2.Location = new Point(cup2.Location.X, cup2.Location.Y - 1);
                cup3.Location = new Point(cup3.Location.X, cup3.Location.Y - 1);
            }
            using (StreamWriter outFile = File.AppendText("gameHistory.txt")) ;
            myTimer.Enabled = false;
            if (magic_coin == 2)
            {
                winStatus.Text = "Win";
                winState = "win";
                total += bidAmmt;
            }
            else
            {
                winStatus.Text = "Lose";
                winState = "lose";
                total -= bidAmmt;
            }
            moneyOut.Text = "$" + total;
            using (StreamWriter outFile = File.AppendText("gameHistory.txt"))
            {
                outFile.WriteLine("Game Win, Cup 3 Choose " + betIn.Text + " " + total.ToString() + "\n");
            }
        }

        private void cup3_Click(object sender, EventArgs e)
        {

            double bidAmmt = Convert.ToDouble(betIn.Text);
            int magic_coin = coinSelect();
            while (cup1.Location.Y >= 44)
            {
                cup1.Location = new Point(cup1.Location.X, cup1.Location.Y - 1);
                cup2.Location = new Point(cup2.Location.X, cup2.Location.Y - 1);
                cup3.Location = new Point(cup3.Location.X, cup3.Location.Y - 1);
            }
            myTimer.Enabled = false;
            if (magic_coin == 3)
            {
                winStatus.Text = "Win";
                winState = "win";
                total += bidAmmt;
            }
            else
            {
                winStatus.Text = "Lose";
                winState = "lose";
                total -= bidAmmt;

            }
            moneyOut.Text = "$" + total;
            using (StreamWriter outFile = File.AppendText("gameHistory.txt"))
            {
                outFile.WriteLine("Game Win, Cup 3 Choose " + betIn.Text + " "+ total.ToString() + "\n");
            }
        }
    }
}
