﻿
namespace _3CardMonte
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.cup1 = new System.Windows.Forms.PictureBox();
            this.coin2 = new System.Windows.Forms.PictureBox();
            this.coin1 = new System.Windows.Forms.PictureBox();
            this.coin3 = new System.Windows.Forms.PictureBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.runButton = new System.Windows.Forms.Button();
            this.moneyOut = new System.Windows.Forms.Label();
            this.moneyLabel = new System.Windows.Forms.Label();
            this.betLabel = new System.Windows.Forms.Label();
            this.betIn = new System.Windows.Forms.TextBox();
            this.cup3 = new System.Windows.Forms.PictureBox();
            this.cup2 = new System.Windows.Forms.PictureBox();
            this.winStatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.cup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cup3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cup2)).BeginInit();
            this.SuspendLayout();
            // 
            // cup1
            // 
            this.cup1.Image = ((System.Drawing.Image)(resources.GetObject("cup1.Image")));
            this.cup1.Location = new System.Drawing.Point(12, 44);
            this.cup1.Name = "cup1";
            this.cup1.Size = new System.Drawing.Size(184, 223);
            this.cup1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cup1.TabIndex = 0;
            this.cup1.TabStop = false;
            this.cup1.Click += new System.EventHandler(this.cup1_Click);
            // 
            // coin2
            // 
            this.coin2.Image = ((System.Drawing.Image)(resources.GetObject("coin2.Image")));
            this.coin2.Location = new System.Drawing.Point(252, 289);
            this.coin2.Name = "coin2";
            this.coin2.Size = new System.Drawing.Size(100, 100);
            this.coin2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin2.TabIndex = 5;
            this.coin2.TabStop = false;
            // 
            // coin1
            // 
            this.coin1.Image = ((System.Drawing.Image)(resources.GetObject("coin1.Image")));
            this.coin1.Location = new System.Drawing.Point(51, 289);
            this.coin1.Name = "coin1";
            this.coin1.Size = new System.Drawing.Size(100, 100);
            this.coin1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin1.TabIndex = 6;
            this.coin1.TabStop = false;
            // 
            // coin3
            // 
            this.coin3.Image = ((System.Drawing.Image)(resources.GetObject("coin3.Image")));
            this.coin3.Location = new System.Drawing.Point(436, 289);
            this.coin3.Name = "coin3";
            this.coin3.Size = new System.Drawing.Size(100, 100);
            this.coin3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.coin3.TabIndex = 7;
            this.coin3.TabStop = false;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(604, 345);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(90, 44);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(604, 289);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(90, 44);
            this.runButton.TabIndex = 9;
            this.runButton.Text = "Run!";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // moneyOut
            // 
            this.moneyOut.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.moneyOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.moneyOut.Location = new System.Drawing.Point(671, 44);
            this.moneyOut.Name = "moneyOut";
            this.moneyOut.Size = new System.Drawing.Size(117, 23);
            this.moneyOut.TabIndex = 10;
            this.moneyOut.Text = "$20.00";
            // 
            // moneyLabel
            // 
            this.moneyLabel.AutoSize = true;
            this.moneyLabel.Location = new System.Drawing.Point(582, 45);
            this.moneyLabel.Name = "moneyLabel";
            this.moneyLabel.Size = new System.Drawing.Size(86, 17);
            this.moneyLabel.TabIndex = 12;
            this.moneyLabel.Text = "Total Money";
            // 
            // betLabel
            // 
            this.betLabel.AutoSize = true;
            this.betLabel.Location = new System.Drawing.Point(576, 123);
            this.betLabel.Name = "betLabel";
            this.betLabel.Size = new System.Drawing.Size(92, 17);
            this.betLabel.TabIndex = 13;
            this.betLabel.Text = "Bet Ammount";
            // 
            // betIn
            // 
            this.betIn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.betIn.Location = new System.Drawing.Point(671, 123);
            this.betIn.Name = "betIn";
            this.betIn.Size = new System.Drawing.Size(117, 22);
            this.betIn.TabIndex = 14;
            // 
            // cup3
            // 
            this.cup3.Image = ((System.Drawing.Image)(resources.GetObject("cup3.Image")));
            this.cup3.Location = new System.Drawing.Point(392, 44);
            this.cup3.Name = "cup3";
            this.cup3.Size = new System.Drawing.Size(184, 223);
            this.cup3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cup3.TabIndex = 15;
            this.cup3.TabStop = false;
            this.cup3.Click += new System.EventHandler(this.cup3_Click);
            // 
            // cup2
            // 
            this.cup2.Image = ((System.Drawing.Image)(resources.GetObject("cup2.Image")));
            this.cup2.Location = new System.Drawing.Point(202, 44);
            this.cup2.Name = "cup2";
            this.cup2.Size = new System.Drawing.Size(184, 223);
            this.cup2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.cup2.TabIndex = 16;
            this.cup2.TabStop = false;
            this.cup2.Click += new System.EventHandler(this.cup2_Click);
            // 
            // winStatus
            // 
            this.winStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.winStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.winStatus.Location = new System.Drawing.Point(582, 161);
            this.winStatus.Name = "winStatus";
            this.winStatus.Size = new System.Drawing.Size(206, 106);
            this.winStatus.TabIndex = 17;
            this.winStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.coin3);
            this.Controls.Add(this.coin2);
            this.Controls.Add(this.coin1);
            this.Controls.Add(this.winStatus);
            this.Controls.Add(this.cup2);
            this.Controls.Add(this.cup3);
            this.Controls.Add(this.betIn);
            this.Controls.Add(this.betLabel);
            this.Controls.Add(this.moneyLabel);
            this.Controls.Add(this.moneyOut);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cup1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.cup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coin3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cup3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cup2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox cup1;
        private System.Windows.Forms.PictureBox coin2;
        private System.Windows.Forms.PictureBox coin1;
        private System.Windows.Forms.PictureBox coin3;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.Label moneyOut;
        private System.Windows.Forms.Label moneyLabel;
        private System.Windows.Forms.Label betLabel;
        private System.Windows.Forms.TextBox betIn;
        private System.Windows.Forms.PictureBox cup3;
        private System.Windows.Forms.PictureBox cup2;
        private System.Windows.Forms.Label winStatus;
    }
}

